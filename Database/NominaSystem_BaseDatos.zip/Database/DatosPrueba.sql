﻿USE [NominaSystemDB];
GO

/* Datos de prueba ficticios para revisar los catalogos y relaciones principales.
   Se pueden ejecutar mas de una vez sin duplicar los registros de ejemplo. */

SET NOCOUNT ON;
SET XACT_ABORT ON;
BEGIN TRANSACTION;

IF NOT EXISTS (SELECT 1 FROM dbo.Empresa WHERE RazonSocial = N'Empresa Demo Nomina System')
BEGIN
    INSERT dbo.Empresa
        (RazonSocial, NombreComercial, RUC, Telefono, Correo, Direccion,
         Municipio, Departamento, Activa, FechaRegistro)
    VALUES
        (N'Empresa Demo Nomina System', N'Empresa Demo', N'J0000000000000',
         N'0000-0000', N'demo@ejemplo.local', N'Direccion de prueba',
         N'Managua', N'Managua', 1, SYSDATETIME());
END;

IF NOT EXISTS (SELECT 1 FROM dbo.PeriodicidadNomina WHERE Codigo = 'QUINCENAL')
    INSERT dbo.PeriodicidadNomina (Codigo, Nombre, EsPredeterminada, Activa)
    VALUES ('QUINCENAL', N'Quincenal', 1, 1);

IF NOT EXISTS (SELECT 1 FROM dbo.TipoContrato WHERE Codigo = 'INDEFINIDO')
    INSERT dbo.TipoContrato (Codigo, Nombre, Descripcion, RequiereFechaFin, Activo)
    VALUES ('INDEFINIDO', N'Tiempo indeterminado', N'Contrato de ejemplo sin fecha final', 0, 1);

IF NOT EXISTS (SELECT 1 FROM dbo.Rol WHERE Codigo = 'ADMINISTRADOR')
    INSERT dbo.Rol (Codigo, Nombre, Descripcion, Activo)
    VALUES ('ADMINISTRADOR', N'Administrador', N'Rol administrativo de prueba', 1);

IF NOT EXISTS (SELECT 1 FROM dbo.Rol WHERE Codigo = 'RRHH')
    INSERT dbo.Rol (Codigo, Nombre, Descripcion, Activo)
    VALUES ('RRHH', N'Recursos Humanos', N'Rol de consulta y gestion de personal', 1);

IF NOT EXISTS (SELECT 1 FROM dbo.TipoIngreso WHERE Codigo = 'BONO_DEMO')
    INSERT dbo.TipoIngreso (Codigo, Nombre, Descripcion, AfectaIR, CotizaINSS, EsRecurrente, Activo)
    VALUES ('BONO_DEMO', N'Bono de prueba', N'Concepto ficticio para pruebas', 1, 1, 0, 1);

IF NOT EXISTS (SELECT 1 FROM dbo.TipoDeduccion WHERE Codigo = 'DEDUCCION_DEMO')
    INSERT dbo.TipoDeduccion (Codigo, Nombre, Clasificacion, Descripcion, EsRecurrente, Activo)
    VALUES ('DEDUCCION_DEMO', N'Deduccion de prueba', 'OTRA', N'Concepto ficticio para pruebas', 0, 1);

IF NOT EXISTS (SELECT 1 FROM dbo.TipoSubsidio WHERE Codigo = 'SUBSIDIO_DEMO')
    INSERT dbo.TipoSubsidio (Codigo, Nombre, Descripcion, Activo)
    VALUES ('SUBSIDIO_DEMO', N'Subsidio de prueba', N'Registro ficticio para pruebas', 1);

DECLARE @EmpresaId INT = (SELECT TOP (1) EmpresaId FROM dbo.Empresa WHERE RazonSocial = N'Empresa Demo Nomina System');
DECLARE @CargoId INT;
DECLARE @EmpleadoId INT;
DECLARE @TipoContratoId TINYINT;

IF NOT EXISTS (SELECT 1 FROM dbo.Cargo WHERE EmpresaId = @EmpresaId AND Nombre = N'Asistente administrativo')
    INSERT dbo.Cargo (EmpresaId, Nombre, Descripcion, Activo, FechaRegistro)
    VALUES (@EmpresaId, N'Asistente administrativo', N'Cargo de ejemplo', 1, SYSDATETIME());

SET @CargoId = (SELECT TOP (1) CargoId FROM dbo.Cargo WHERE EmpresaId = @EmpresaId AND Nombre = N'Asistente administrativo');
SET @TipoContratoId = (SELECT TOP (1) TipoContratoId FROM dbo.TipoContrato WHERE Codigo = 'INDEFINIDO');

IF NOT EXISTS (SELECT 1 FROM dbo.Empleado WHERE EmpresaId = @EmpresaId AND CodigoEmpleado = N'DEMO-001')
    INSERT dbo.Empleado
        (EmpresaId, CodigoEmpleado, Nombres, Apellidos, FechaIngreso, Estado, Observaciones, FechaRegistro)
    VALUES
        (@EmpresaId, N'DEMO-001', N'Empleado', N'De Prueba', '2026-01-05', 'ACTIVO',
         N'Registro ficticio para comprobar el funcionamiento del sistema.', SYSDATETIME());

SET @EmpleadoId = (SELECT TOP (1) EmpleadoId FROM dbo.Empleado WHERE EmpresaId = @EmpresaId AND CodigoEmpleado = N'DEMO-001');

IF NOT EXISTS (SELECT 1 FROM dbo.Contrato WHERE EmpresaId = @EmpresaId AND NumeroContrato = N'DEMO-CT-001')
    INSERT dbo.Contrato
        (EmpresaId, EmpleadoId, CargoId, TipoContratoId, NumeroContrato, FechaInicio,
         SalarioBaseMensual, Moneda, Jornada, HorasSemanales, Estado, Observaciones, FechaRegistro)
    VALUES
        (@EmpresaId, @EmpleadoId, @CargoId, @TipoContratoId, N'DEMO-CT-001', '2026-01-05',
         18000.00, 'NIO', N'Tiempo completo', 48.00, 'VIGENTE',
         N'Contrato ficticio para pruebas; no representa a una persona real.', SYSDATETIME());

COMMIT TRANSACTION;
GO

SELECT N'Empresa demo, catalogos, cargo, empleado y contrato de prueba registrados.' AS Resultado;
GO
